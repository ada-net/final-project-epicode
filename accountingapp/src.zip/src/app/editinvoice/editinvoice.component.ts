import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editinvoice',
  templateUrl: './editinvoice.component.html',
  styleUrls: ['./editinvoice.component.css']
})
export class EditinvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
