import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editclient',
  templateUrl: './editclient.component.html',
  styleUrls: ['./editclient.component.css']
})
export class EditclientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
