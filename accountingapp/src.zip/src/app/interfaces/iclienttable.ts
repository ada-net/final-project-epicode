import { Iclient } from "./iclient";

export interface Iclienttable {
    content: Iclient[];
}
