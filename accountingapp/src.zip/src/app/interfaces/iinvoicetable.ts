import { Iinvoice } from "./iinvoice";

export interface Iinvoicetable {
    content: Iinvoice[];
}
